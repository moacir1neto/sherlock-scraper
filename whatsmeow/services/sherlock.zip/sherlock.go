package services

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/verbeux-ai/whatsmiau/env"
	"github.com/verbeux-ai/whatsmiau/server/dto"
	"go.uber.org/zap"
)

type SherlockService struct {
	httpClient *http.Client
	baseURL    string
}

func NewSherlockService() *SherlockService {
	return &SherlockService{
		httpClient: &http.Client{
			Timeout: 90 * time.Second, // Timeout longo para extração síncrona
		},
		baseURL: env.Env.SherlockURL,
	}
}

func (s *SherlockService) ExtractLeads(req dto.ExtractLeadsRequest) (*dto.ExtractLeadsResponse, error) {
	apiUrl := fmt.Sprintf("%s/api/v1/search", s.baseURL)
	
	jsonData, err := json.Marshal(req)
	if err != nil {
		zap.L().Error("failed to marshal sherlock request", zap.Error(err))
		return nil, err
	}

	zap.L().Info("triggering lead extraction in sherlock", 
		zap.String("url", apiUrl),
		zap.String("keyword", req.Keyword),
		zap.String("location", req.Location),
	)

	resp, err := s.httpClient.Post(apiUrl, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		zap.L().Error("failed to call sherlock api", zap.Error(err))
		return nil, fmt.Errorf("sherlock api unreachable: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		zap.L().Warn("sherlock api returned non-ok status", zap.Int("status", resp.StatusCode))
		return nil, fmt.Errorf("sherlock api error: status %d", resp.StatusCode)
	}

	var result dto.ExtractLeadsResponse
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		zap.L().Error("failed to decode sherlock response", zap.Error(err))
		return nil, err
	}

	zap.L().Info("lead extraction completed", zap.Int("leads_found", len(result.Leads)))
	return &result, nil
}
